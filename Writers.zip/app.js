var path = require('path');
var express = require('express');
var app = express();

app.use(express.static(path.join(__dirname, './public'))); // если сайт лежит в папке public в корне проекта
app.get('/', function(req, res) {
  res.sendFile('./public/writers_mapbox.html');
});
app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});
